package logica;

public class Operaciones {

    private double valor = 0, resultado = 0;
    private int divisa;

    //CONSTRUCTOR
    public Operaciones() {
    }

    //GETTERS & SETTERS
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public int getDivisa() {
        return divisa;
    }

    public void setDivisa(int divisa) {
        this.divisa = divisa;
    }

    //METODOS
    public double convertir() {

        switch (divisa) {
            case 0:
                resultado = valor * 0.053;
                break;
            case 1:
                resultado = valor * 0.050;
                break;
            case 2:
                resultado = valor * 0.044;
                break;
            case 3:
                resultado = valor * 7.12;//yen
                break;
            case 4:
                resultado = valor * 69.50;
                break;
            case 5:
                resultado = valor * 18.71;
                break;
            case 6:
                resultado = valor * 19.92;
                break;
            case 7:
                resultado = valor * 22.73;
                break;
            case 8:
                resultado = valor * 0.14;
                break;
            case 9:
                resultado = valor * 0.014;
                break;
            default:
                break;

        }
        return resultado;
    }

}
