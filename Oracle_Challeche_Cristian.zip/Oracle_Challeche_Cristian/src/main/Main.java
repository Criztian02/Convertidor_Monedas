package main;

import gui.Pantalla;

public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        Pantalla pantalla = new Pantalla();
        pantalla.setVisible(true);
        pantalla.setLocationRelativeTo(null);
    }

}
